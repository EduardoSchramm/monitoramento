# server.py
import os
import unicodedata
import time
import requests
import pandas as pd
from flask import Flask, jsonify, send_from_directory

# === Configurações ===
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROMOTORIAS_FILE = os.path.join(BASE_DIR, "Promotorias.xlsx")
HOSTS_FILE = os.path.join(BASE_DIR, "Host_nagiosmpls.xlsx")
NAGIOS_URL = "http://nagiosmpls.mp.rs.gov.br/nagios/cgi-bin/statusjson.cgi"

# === App Flask ===
app = Flask(__name__, static_folder="static")


def normalize(s: str) -> str:
    if not isinstance(s, str):
        return ""
    s = s.lower().replace("_", " ").strip()
    s = unicodedata.normalize("NFKD", s)
    return "".join(c for c in s if not unicodedata.combining(c))


def load_data():
    # Lê planilhas (usa engine openpyxl, conforme recomendado)
    prom = pd.read_excel(PROMOTORIAS_FILE, engine="openpyxl")
    hosts = pd.read_excel(HOSTS_FILE, engine="openpyxl")

    # Normaliza chaves
    prom["key"] = prom["MUNICÍPIO"].apply(normalize)
    hosts["key"] = hosts["Host"].apply(normalize)

    # Interseção 1:1 por key
    merged = prom.merge(hosts[["Host", "key"]], on="key", how="inner")

    # Monta lista base
    lista = []
    for _, row in merged.iterrows():
        lista.append({
            "nome": str(row["MUNICÍPIO"]).strip(),
            "lat": float(row["LATITUDE"]),
            "lng": float(row["LONGITUDE"]),
            "status_local": str(row.get("STATUS", "")).strip() or "UP",
            "host": str(row["Host"]).strip()
        })
    return lista


# Carrega dados na inicialização
PROMOTORIAS = load_data()

# Cache curto para aliviar o Nagios quando houver muitos acessos
_last_cache = {"ts": 0, "data": None}
CACHE_SECONDS = 10


def estado_nagios(host):
    try:
        r = requests.get(f"{NAGIOS_URL}?query=host&hostname={host}", timeout=5)
        r.raise_for_status()
        data = r.json()
        st = data["data"]["hoststatus"]["current_state"]  # 0/1/2/3
        return ["OK", "WARNING", "CRITICAL", "UNKNOWN"][st]
    except Exception:
        return "UNKNOWN"


@app.route("/api/status")
def api_status():
    now = time.time()
    if _last_cache["data"] is not None and (now - _last_cache["ts"] < CACHE_SECONDS):
        return jsonify(_last_cache["data"])

    resultado = []
    for p in PROMOTORIAS:
        st = estado_nagios(p["host"])
        resultado.append({
            "nome": p["nome"],
            "lat": p["lat"],
            "lng": p["lng"],
            "host": p["host"],
            "status_local": p["status_local"],
            "status_nagios": st
        })
    _last_cache["data"] = resultado
    _last_cache["ts"] = now
    return jsonify(resultado)


@app.route("/")
def root():
    return send_from_directory("static", "index.html")


@app.route("/<path:path>")
def static_proxy(path):
    return send_from_directory("static", path)


if __name__ == "__main__":
    # Somente local
    app.run(host="127.0.0.1", port=8080, debug=False)
