# Mapa das Promotorias – Simulação Local

## Como usar
1. Extraia este ZIP para `C:\monitoramento_promotorias` (ou qualquer pasta).
2. Abra o **PowerShell** na pasta e rode:

```
py -3 -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python server.py
```

3. Abra o navegador em: http://localhost:8080/

## Atualização dos dados
- Substitua os arquivos `Promotorias.xlsx` e `Host_nagiosmpls.xlsx` pelos seus arquivos oficiais.
- Reinicie o `server.py` para recarregar as planilhas.

## Observação
- Se o Nagios exigir autenticação/cookie, ajuste o `server.py` para incluir `auth=(user, pass)` ou cabeçalho de `Cookie` na função `estado_nagios()`.
