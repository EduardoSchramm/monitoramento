// ======================= MAPA ===========================
const map = L.map('map').setView([-30, -51], 7);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 18
}).addTo(map);

const iconBase = 'icons/';

// ======================= FUNÇÃO DE ÍCONES ===========================
function iconStatus(st) {
  st = (st || "").toUpperCase();
  let file = "unknown.png"; // padrão
  if (st === "UP") file = "up.png";
  else if (st === "DOWN") file = "down.png";
  else if (st === "WARNING") file = "warning.png";
  else if (st === "UNKNOWN" || st === "UNKNOW") file = "unknown.png"; 

  return L.icon({
    iconUrl: iconBase + file,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -28]
  });
}

// ======================= CLUSTER ===========================
const clusterGroup = L.markerClusterGroup({
  chunkedLoading: true,
  maxClusterRadius: 50,
  spiderfyOnMaxZoom: true,
  showCoverageOnHover: false, 
  iconCreateFunction: function (cluster) {
    const children = cluster.getAllChildMarkers();
    const count = children.length;

    const hasDown = children.some(m =>
      ((m.options.statusNagios || '') + '').toUpperCase() === 'DOWN'
    );

    const size = count < 10 ? 28 : (count < 50 ? 34 : 40);

    return L.divIcon({
      html: `${count}`,
      className: `cluster-base ${hasDown ? 'cluster-warn' : 'cluster-ok'}`,
      iconSize: [size, size]
    });
  }
});

map.addLayer(clusterGroup);

const markers = {};
const popupTimers = {};

// ======================= FORMATADORES ===========================
function fmtEpochMs(ms) {
  if (!ms || ms <= 0) return '—';
  try {
    return new Date(ms).toLocaleString();
  } catch {
    return '—';
  }
}

function fmtDurationMs(ms) {
  if (!ms || ms <= 0) return '—';

  const sec = Math.floor(ms / 1000);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;

  const parts = [];
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  if (s || !parts.length) parts.push(`${s}s`);

  return parts.join(' ');
}

// Duração dinâmica baseada em last_time_up
function fmtDynamicDownDuration(lastUpMs) {
  if (!lastUpMs || lastUpMs <= 0) return '—';
  const now = Date.now();
  const diff = now - lastUpMs;
  return fmtDurationMs(diff);
}

// ======================= POPUP ===========================
function popupHtml(p, dynamic = false) {
  let dur;

  if ((p.status_nagios || '').toUpperCase() === "DOWN" && dynamic) {
    dur = fmtDynamicDownDuration(p.last_time_up);
  } else {
    dur = fmtDurationMs(p.last_downtime_duration_ms);
  }

  const plugin = (p.plugin_output || '—').toString();

  return `
    <b>${p.nome}</b><br>
    Host: ${p.host}<br>
    Status Nagios: <b>${p.status_nagios}</b><br>
    Flapping: <b>${p.is_flapping ? 'Sim' : 'Não'}</b><br>
    Último DOWN: ${fmtEpochMs(p.last_time_down)}<br>
    Último UP após DOWN: ${fmtEpochMs(p.last_time_up)}<br>

    <b>Duração do último DOWN:</b> ${dur}<br>

    Plugin:<br>
    <pre style="white-space:pre-wrap;margin:4px 0 0">${plugin}</pre>
  `;
}

function attachHandlersOnce(marker, key) {
  if (marker._handlersAttached) return;

  marker.on('popupopen', () => {
    if (popupTimers[key]) clearInterval(popupTimers[key]);

    const data = marker.options._data || {};
    if ((data.status_nagios || '').toUpperCase() !== 'DOWN') return;

    popupTimers[key] = setInterval(() => {
      const current = marker.options._data || {};
      marker.setPopupContent(popupHtml(current, true));
    }, 1000);
  });

  marker.on('popupclose', () => {
    if (popupTimers[key]) {
      clearInterval(popupTimers[key]);
      delete popupTimers[key];
    }
  });

  marker._handlersAttached = true;
}

function updateMarkerVisual(marker, p) {
  // Atualiza dados correntes no marker
  marker.options._data = p;
  marker.options.statusNagios = p.status_nagios;
  marker.setIcon(iconStatus(p.status_nagios));
  marker.setPopupContent(popupHtml(p, true));

  // Atualiza animação
  const el = marker.getElement();
  if (el) {
    if ((p.status_nagios || '').toUpperCase() === 'DOWN') el.classList.add('blinking-icon');
    else el.classList.remove('blinking-icon');
  }
}

// ======================= ATUALIZAÇÃO ===========================
async function atualizar() {
  try {
    const dados = await fetch('/api/status').then(r => r.json());

    dados.forEach(p => {
      const key = p.host;

      if (!markers[key]) {
        // Criar novo marcador
        const m = L.marker([p.lat, p.lng], {
          icon: iconStatus(p.status_nagios),
          statusNagios: p.status_nagios,
          _data: p
        });

        m.bindPopup(popupHtml(p, true));
        markers[key] = m;
        clusterGroup.addLayer(m);

        // Animação DOWN ao adicionar
        m.on('add', () => {
          const el = m.getElement();
          if (!el) return;
          if ((p.status_nagios || '').toUpperCase() === 'DOWN') el.classList.add('blinking-icon');
          else el.classList.remove('blinking-icon');
        });

        // Handlers de popup/timer, uma única vez
        attachHandlersOnce(m, key);

      } else {
        // Atualizar marcador existente
        updateMarkerVisual(markers[key], p);
      }
    });

  } catch (e) {
    console.error('Falha ao atualizar:', e);
  }
}

// Atualiza inicialmente e a cada 30s
atualizar();
setInterval(atualizar, 30000);
