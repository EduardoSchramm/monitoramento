# Mapa das Promotorias – Status em Tempo Real

Projeto para exibir em mapa os hosts/municípios com status do Nagios, com clusterização, ícones e popup com detalhes.

## Requisitos

- Python 3.9+
- `pip install -r requirements.txt`
- Planilhas:
  - `Promotorias.xlsx`
  - `Host_nagiosmpls.xlsx`
  (coloque na raiz do projeto)

## Executar

```bash
python server.py
```

Acesse: http://127.0.0.1:8080/

## Observações
- O backend consolida consulta única ao Nagios e retorna campos adicionais.
- O popup exibe duração dinâmica quando o host está DOWN (baseado em `last_time_up`).
- Ícones de estado devem estar em `static/icons/` (`up.png`, `down.png`, `warning.png`, `unknown.png`).
