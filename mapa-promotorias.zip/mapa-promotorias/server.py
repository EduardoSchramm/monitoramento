# server.py (versão consolidada)
import os
import time
import unicodedata
import requests
import pandas as pd
import getpass
from flask import Flask, jsonify, send_from_directory

# -------------------------------------------------------------------
# PATHS E CONFIG
# -------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROMOTORIAS_FILE = os.path.join(BASE_DIR, 'Promotorias.xlsx')
HOSTS_FILE = os.path.join(BASE_DIR, 'Host_nagiosmpls.xlsx')
NAGIOS_URL = 'http://nagiosmpls.mp.rs.gov.br/nagios/cgi-bin/statusjson.cgi'

# -------------------------------------------------------------------
# LOGIN NO NAGIOS
# -------------------------------------------------------------------
print("\n=== Login no Nagios ===")
NAGIOS_USER = input("Usuário: ").strip()
NAGIOS_PASS = getpass.getpass("Senha: ").strip()

session = requests.Session()
app = Flask(__name__, static_folder='static')

# -------------------------------------------------------------------
# FUNÇÕES AUXILIARES
# -------------------------------------------------------------------
def strip_nbsp(s: str) -> str:
    if not isinstance(s, str):
        return ''
    return s.replace('\xa0', ' ').strip()

def normalize(s: str) -> str:
    s = strip_nbsp(s)
    s = s.lower().replace('_', ' ')
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(ch for ch in s if not unicodedata.combining(ch))
    return ' '.join(s.split())

def find_col(df: pd.DataFrame, keywords):
    cols = list(df.columns)
    norm = {c: normalize(str(c)) for c in cols}
    for c, n in norm.items():
        for kw in keywords:
            if kw in n:
                return c
    return None

# -------------------------------------------------------------------
# CARREGA PLANILHAS
# -------------------------------------------------------------------
def load_data():
    prom = pd.read_excel(PROMOTORIAS_FILE, engine='openpyxl')
    hosts = pd.read_excel(HOSTS_FILE, engine='openpyxl')

    col_mun = find_col(prom, ['municipio'])
    col_lat = find_col(prom, ['latitude'])
    col_lng = find_col(prom, ['longitude'])
    col_sts = find_col(prom, ['status'])

    if not all([col_mun, col_lat, col_lng]):
        raise Exception(f'Colunas não encontradas em Promotorias.xlsx: {prom.columns.tolist()}')

    col_host = find_col(hosts, ['host'])
    if not col_host:
        raise Exception(f"Coluna 'Host' não encontrada em Host_nagiosmpls.xlsx: {hosts.columns.tolist()}")

    prom['key'] = prom[col_mun].astype(str).apply(normalize)
    hosts['key'] = hosts[col_host].astype(str).apply(normalize)

    merged = prom.merge(hosts[[col_host, 'key']], on='key', how='inner')

    lista = []
    for _, row in merged.iterrows():
        lista.append({
            'nome': strip_nbsp(str(row[col_mun])),
            'lat': float(row[col_lat]),
            'lng': float(row[col_lng]),
            'status_local': strip_nbsp(str(row[col_sts])) if col_sts else 'UP',
            'host': strip_nbsp(str(row[col_host]))
        })

    return lista

PROMOTORIAS = load_data()
PROMOTORIAS_MTIME = os.path.getmtime(PROMOTORIAS_FILE)
HOSTS_MTIME = os.path.getmtime(HOSTS_FILE)

def reload_if_needed():
    global PROMOTORIAS, PROMOTORIAS_MTIME, HOSTS_MTIME
    pm = os.path.getmtime(PROMOTORIAS_FILE)
    hm = os.path.getmtime(HOSTS_FILE)
    if pm != PROMOTORIAS_MTIME or hm != HOSTS_MTIME:
        print("\n🔄 Detectada alteração nas planilhas. Recarregando dados...")
        PROMOTORIAS = load_data()
        PROMOTORIAS_MTIME = pm
        HOSTS_MTIME = hm
    return PROMOTORIAS

# -------------------------------------------------------------------
# CONSULTA CONSOLIDADA AO NAGIOS
# -------------------------------------------------------------------
def map_status(code: int) -> str:
    """
    2 -> UP
    4 -> DOWN
    0 -> UNKNOWN
    demais -> WARNING
    """
    if code == 2:
        return "UP"
    if code == 4:
        return "DOWN"
    if code == 0:
        return "UNKNOWN"
    return "WARNING"


def get_host_info(host: str) -> dict:
    """
    Consulta única ao Nagios:
      - status_nagios
      - plugin_output
      - is_flapping
      - last_time_down / last_time_up
      - duração do último down
    """
    try:
        url = f"{NAGIOS_URL}?query=host&hostname={host}"
        r = session.get(url, auth=(NAGIOS_USER, NAGIOS_PASS), timeout=8)
        r.raise_for_status()
        data = r.json()

        hostdata = data.get("data", {}).get("host", {}) or {}

        raw_status = hostdata.get("status")
        status_nagios = "UNKNOWN"
        if raw_status is not None:
            status_nagios = map_status(int(raw_status))

        is_flapping = bool(hostdata.get("is_flapping", False))
        last_time_down = int(hostdata.get("last_time_down", 0) or 0)
        last_time_up = int(hostdata.get("last_time_up", 0) or 0)
        plugin_output = hostdata.get("plugin_output", "") or ""

        duration = last_time_up - last_time_down
        if duration < 0:
            duration = 0

        return {
            "status_nagios": status_nagios,
            "plugin_output": plugin_output,
            "is_flapping": is_flapping,
            "last_time_down": last_time_down,
            "last_time_up": last_time_up,
            "last_downtime_duration_ms": duration
        }

    except Exception:
        return {
            "status_nagios": "UNKNOWN",
            "plugin_output": "",
            "is_flapping": False,
            "last_time_down": 0,
            "last_time_up": 0,
            "last_downtime_duration_ms": 0
        }

# -------------------------------------------------------------------
# API
# -------------------------------------------------------------------
_cache = {"ts": 0.0, "data": None}
CACHE_SECONDS = 10

@app.route('/api/status')
def api_status():
    now = time.time()
    if _cache["data"] is not None and (now - _cache["ts"] < CACHE_SECONDS):
        return jsonify(_cache["data"])

    lista = reload_if_needed()
    out = []

    for p in lista:
        info = get_host_info(p["host"])
        out.append({
            "nome": p["nome"],
            "lat": p["lat"],
            "lng": p["lng"],
            "host": p["host"],
            "status_local": p["status_local"],
            "status_nagios": info["status_nagios"],
            "plugin_output": info["plugin_output"],
            "is_flapping": info["is_flapping"],
            "last_time_down": info["last_time_down"],
            "last_time_up": info["last_time_up"],
            "last_downtime_duration_ms": info["last_downtime_duration_ms"]
        })

    _cache["data"] = out
    _cache["ts"] = now
    return jsonify(out)

# -------------------------------------------------------------------
# ROTAS ESTÁTICAS
# -------------------------------------------------------------------
@app.route('/')
def root():
    return send_from_directory('static', 'index.html')

@app.route('/<path:path>')
def static_proxy(path):
    return send_from_directory('static', path)

# -------------------------------------------------------------------
# MAIN
# -------------------------------------------------------------------
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=False)
