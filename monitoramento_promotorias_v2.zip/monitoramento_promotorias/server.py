# server.py (v2 - robust column detection + NBSP fix + optional auth)
import os
import time
import unicodedata
import requests
import pandas as pd
from flask import Flask, jsonify, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROMOTORIAS_FILE = os.path.join(BASE_DIR, 'Promotorias.xlsx')
HOSTS_FILE = os.path.join(BASE_DIR, 'Host_nagiosmpls.xlsx')
NAGIOS_URL = 'http://nagiosmpls.mp.rs.gov.br/nagios/cgi-bin/statusjson.cgi'

# Optional auth
NAGIOS_USER = os.getenv('NAGIOS_USER')
NAGIOS_PASS = os.getenv('NAGIOS_PASS')
NAGIOS_COOKIE = os.getenv('NAGIOS_COOKIE')

session = requests.Session()
if NAGIOS_COOKIE:
    session.headers.update({'Cookie': NAGIOS_COOKIE})

app = Flask(__name__, static_folder='static')


def strip_nbsp(s: str) -> str:
    if not isinstance(s, str):
        return ''
    return s.replace('\xa0', ' ').strip()


def normalize(s: str) -> str:
    s = strip_nbsp(s)
    s = s.lower().replace('_', ' ')
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(ch for ch in s if not unicodedata.combining(ch))
    return ' '.join(s.split())


def find_col(df: pd.DataFrame, keywords):
    # returns first column whose normalized name contains any of the keywords
    cols = list(df.columns)
    norm = {c: normalize(str(c)) for c in cols}
    for c, n in norm.items():
        for kw in keywords:
            if kw in n:
                return c
    return None


def load_data():
    prom = pd.read_excel(PROMOTORIAS_FILE, engine='openpyxl')
    hosts = pd.read_excel(HOSTS_FILE, engine='openpyxl')

    # Detect columns on promotorias
    col_mun = find_col(prom, ['municipio'])
    col_lat = find_col(prom, ['latitude'])
    col_lng = find_col(prom, ['longitude'])
    col_sts = find_col(prom, ['status'])

    if not all([col_mun, col_lat, col_lng]):
        raise Exception(f'Colunas não encontradas em Promotorias.xlsx. Colunas: {prom.columns.tolist()}')

    # Detect host column (with NBSP tolerance) on hosts
    col_host = find_col(hosts, ['host'])
    if not col_host:
        raise Exception(f"Coluna 'Host' não encontrada em Host_nagiosmpls.xlsx. Colunas: {hosts.columns.tolist()}")

    prom['key'] = prom[col_mun].astype(str).apply(normalize)
    hosts['key'] = hosts[col_host].astype(str).apply(normalize)

    merged = prom.merge(hosts[[col_host, 'key']], on='key', how='inner')

    lista = []
    for _, row in merged.iterrows():
        lista.append({
            'nome': strip_nbsp(str(row[col_mun])),
            'lat': float(row[col_lat]),
            'lng': float(row[col_lng]),
            'status_local': strip_nbsp(str(row[col_sts])) if col_sts else 'UP',
            'host': strip_nbsp(str(row[col_host]))
        })
    return lista


PROMOTORIAS = load_data()

_cache = {'ts': 0.0, 'data': None}
CACHE_SECONDS = 10


STATE_MAP = {
    0: 'OK',
    1: 'WARNING',
    2: 'CRITICAL',
    3: 'UNKNOWN'
}


def estado_nagios(host: str) -> str:
    try:
        url = f"{NAGIOS_URL}?query=host&hostname={host}"
        if NAGIOS_USER and NAGIOS_PASS and not NAGIOS_COOKIE:
            r = session.get(url, auth=(NAGIOS_USER, NAGIOS_PASS), timeout=6)
        else:
            r = session.get(url, timeout=6)
        r.raise_for_status()
        data = r.json()
        state = int(data.get('data', {}).get('hoststatus', {}).get('current_state', 3))
        return STATE_MAP.get(state, 'UNKNOWN')
    except Exception:
        return 'UNKNOWN'


@app.route('/api/status')
def api_status():
    import time as _t
    now = _t.time()
    if _cache['data'] is not None and (now - _cache['ts'] < CACHE_SECONDS):
        return jsonify(_cache['data'])

    out = []
    for p in PROMOTORIAS:
        st = estado_nagios(p['host'])
        out.append({
            'nome': p['nome'],
            'lat': p['lat'],
            'lng': p['lng'],
            'host': p['host'],
            'status_local': p['status_local'],
            'status_nagios': st
        })
    _cache['data'] = out
    _cache['ts'] = now
    return jsonify(out)


@app.route('/')
def root():
    return send_from_directory('static', 'index.html')


@app.route('/<path:path>')
def static_proxy(path):
    return send_from_directory('static', path)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=False)
